import React from 'react';
import ReactDOM from 'react-dom/client';
import AppOtr from './AppOtr';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AppOtr/>
  </React.StrictMode>
);